#
# This file is part of VIRL 2
# Copyright (c) 2019, Cisco Systems, Inc.
# All rights reserved.
#

import io
import logging


class PyatsNotInstalled(Exception):
    pass


logger = logging.getLogger(__name__)


class PyatsDeviceNotFound(object):
    pass


class ClPyats:

    def __init__(self, lab):
        self._pyats_installed = False
        self._lab = lab
        try:
            import pyats  # noqa: F401
        except ImportError:
            return
        else:
            self._pyats_installed = True

        self._testbed = None
        self._connections = []

    def _check_pyats_installed(self):
        if not self._pyats_installed:
            raise PyatsNotInstalled

    def sync_testbed(self):
        """Sync the testbed from the server. Note that this will always fetch the latest from the server"""
        self._check_pyats_installed()
        from pyats.topology import loader
        testbed_yaml = self._lab.get_pyats_testbed()
        self._testbed = loader.load(io.StringIO(testbed_yaml))

    def run_command(self, node_label, command):
        self._check_pyats_installed()

        try:
            pyats_device = self._testbed.devices[node_label]
        except KeyError:
            raise PyatsDeviceNotFound(node_label)

        # TODO: later check if connected
        # TODO: later look at pooling connections
        pyats_device.connect(log_stdout=False)
        self._connections.append(pyats_device)
        return pyats_device.execute(command, log_stdout=False)

    def cleanup(self):
        for pyats_device in self._connections:
            pyats_device.destroy()
